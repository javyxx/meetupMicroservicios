package es.paradigma.service.agregation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AgregationApplication {

	public static void main(String[] args) {
		SpringApplication.run(AgregationApplication.class, args);
	}
}
